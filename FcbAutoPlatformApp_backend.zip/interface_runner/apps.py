from django.apps import AppConfig


class InterfaceRunnerConfig(AppConfig):
    name = 'interface_runner'
