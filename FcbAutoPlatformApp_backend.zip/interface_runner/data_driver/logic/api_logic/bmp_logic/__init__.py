# __init__.py
__all__ = ['bmp_mgr_login_cmd','bmp_mini_login_cmd']