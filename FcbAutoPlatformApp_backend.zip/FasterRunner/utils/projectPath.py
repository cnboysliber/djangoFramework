import os



path_project = os.path.split(os.path.split(os.path.split(os.path.realpath(__file__))[0])[0])[0]  #当前项目路径
