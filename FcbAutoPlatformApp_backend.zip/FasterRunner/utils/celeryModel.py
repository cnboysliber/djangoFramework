from djcelery import models as celery_models



