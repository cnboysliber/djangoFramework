# coding: utf-8


NOT_ACTIVE = 0
ACTIVE = 1

MASTER = 1
SLAVE = 0
