from django.apps import AppConfig


class PerformAppConfig(AppConfig):
    name = 'performApp'
