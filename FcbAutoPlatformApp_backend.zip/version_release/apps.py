from django.apps import AppConfig


class VersionReleaseConfig(AppConfig):
    name = 'version_release'
